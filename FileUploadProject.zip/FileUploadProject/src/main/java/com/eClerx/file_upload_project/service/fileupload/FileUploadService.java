package com.eClerx.file_upload_project.service.fileupload;

import com.eClerx.file_upload_project.entity.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {
    public ResponseEntity<Object> uploadToLocal(MultipartFile file, User user);
}
