package com.eClerx.file_upload_project.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
public class User
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer userId;
    private String userName;
    private String mobile;
    private String email;
    private String panCard;
    private String collateral;
    private Integer income;
    private Integer cibilScore;
    private String accountNumber;

}
