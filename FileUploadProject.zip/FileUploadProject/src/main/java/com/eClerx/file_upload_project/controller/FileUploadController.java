package com.eClerx.file_upload_project.controller;

import com.eClerx.file_upload_project.entity.User;
import com.eClerx.file_upload_project.service.fileupload.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class FileUploadController {

    @Autowired
    private FileUploadService fileUploadService;

    @PostMapping("/upload/local")
    public ResponseEntity<String> uploadLocal(@RequestPart("file") MultipartFile multipartFile, @RequestPart User user) {
        fileUploadService.uploadToLocal(multipartFile, user);
        if (multipartFile.isEmpty()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Request must contain file");
        }
        return ResponseEntity.ok("working");
    }
}